--------------------------------------------------------
--  DDL for Table CVAP_COMPLETION
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVAP_COMPLETION" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER
   )
