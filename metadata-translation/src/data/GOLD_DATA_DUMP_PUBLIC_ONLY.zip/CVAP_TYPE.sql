--------------------------------------------------------
--  DDL for Table CVAP_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVAP_TYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER
   )
