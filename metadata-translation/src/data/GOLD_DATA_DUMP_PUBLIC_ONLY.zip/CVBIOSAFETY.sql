--------------------------------------------------------
--  DDL for Table CVBIOSAFETY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVBIOSAFETY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50 BYTE), 
	"SEQUENCE" NUMBER
   )
