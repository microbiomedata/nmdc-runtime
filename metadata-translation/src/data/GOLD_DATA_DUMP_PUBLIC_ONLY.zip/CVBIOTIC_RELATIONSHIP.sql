--------------------------------------------------------
--  DDL for Table CVBIOTIC_RELATIONSHIP
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVBIOTIC_RELATIONSHIP" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
