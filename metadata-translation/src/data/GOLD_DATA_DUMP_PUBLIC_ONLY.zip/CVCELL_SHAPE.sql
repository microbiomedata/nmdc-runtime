--------------------------------------------------------
--  DDL for Table CVCELL_SHAPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVCELL_SHAPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
