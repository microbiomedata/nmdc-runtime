--------------------------------------------------------
--  DDL for Table CVDATA_VALIDITY_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVDATA_VALIDITY_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
