--------------------------------------------------------
--  DDL for Table CVDOMAIN
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVDOMAIN" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200 BYTE), 
	"SEQUENCE" NUMBER
   )
