--------------------------------------------------------
--  DDL for Table CVGEBA_PRIORITY_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVGEBA_PRIORITY_STATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50 BYTE), 
	"SEQUENCE" NUMBER
   )
