--------------------------------------------------------
--  DDL for Table CVGEBA_TYPES
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVGEBA_TYPES" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50 BYTE), 
	"SEQUENCE" NUMBER
   )
