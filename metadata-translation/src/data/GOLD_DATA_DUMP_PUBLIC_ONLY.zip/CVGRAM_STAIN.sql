--------------------------------------------------------
--  DDL for Table CVGRAM_STAIN
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVGRAM_STAIN" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
