--------------------------------------------------------
--  DDL for Table CVHABITAT
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHABITAT" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
