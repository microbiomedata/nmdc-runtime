--------------------------------------------------------
--  DDL for Table CVIMGUSE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVIMGUSE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
