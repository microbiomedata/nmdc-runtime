--------------------------------------------------------
--  DDL for Table CVMODEL
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVMODEL" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200 BYTE), 
	"SEQUENCE" NUMBER
   )
