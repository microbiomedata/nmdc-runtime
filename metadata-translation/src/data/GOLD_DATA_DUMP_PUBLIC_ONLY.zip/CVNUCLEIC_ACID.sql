--------------------------------------------------------
--  DDL for Table CVNUCLEIC_ACID
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVNUCLEIC_ACID" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER
   )
