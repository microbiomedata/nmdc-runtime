--------------------------------------------------------
--  DDL for Table CVOXYGEN
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVOXYGEN" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
