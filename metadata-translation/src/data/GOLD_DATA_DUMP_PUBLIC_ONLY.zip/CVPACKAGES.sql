--------------------------------------------------------
--  DDL for Table CVPACKAGES
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPACKAGES" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
