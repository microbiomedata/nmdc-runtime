--------------------------------------------------------
--  DDL for Table CVPHYLOGENY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPHYLOGENY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
