--------------------------------------------------------
--  DDL for Table CVSEQ_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSEQ_STATUS" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
