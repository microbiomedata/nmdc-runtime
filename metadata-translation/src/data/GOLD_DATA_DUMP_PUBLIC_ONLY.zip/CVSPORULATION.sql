--------------------------------------------------------
--  DDL for Table CVSPORULATION
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSPORULATION" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
