--------------------------------------------------------
--  DDL for Table CVTIDAL_STAGE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVTIDAL_STAGE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50 BYTE), 
	"SEQUENCE" NUMBER
   )
