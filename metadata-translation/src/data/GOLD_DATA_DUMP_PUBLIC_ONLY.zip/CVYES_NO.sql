--------------------------------------------------------
--  DDL for Table CVYES_NO
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVYES_NO" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100 BYTE), 
	"SEQUENCE" NUMBER(*,0)
   )
