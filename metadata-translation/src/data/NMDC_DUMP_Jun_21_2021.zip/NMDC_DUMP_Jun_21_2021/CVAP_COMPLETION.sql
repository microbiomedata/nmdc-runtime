--------------------------------------------------------
--  DDL for Table CVAP_COMPLETION
--------------------------------------------------------

  CREATE TABLE "CVAP_COMPLETION" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER
   )
