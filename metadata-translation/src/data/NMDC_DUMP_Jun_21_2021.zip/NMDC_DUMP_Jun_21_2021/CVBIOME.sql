--------------------------------------------------------
--  DDL for Table CVBIOME
--------------------------------------------------------

  CREATE TABLE "CVBIOME" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
