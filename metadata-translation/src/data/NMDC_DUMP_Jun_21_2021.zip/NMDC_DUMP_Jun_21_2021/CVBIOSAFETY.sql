--------------------------------------------------------
--  DDL for Table CVBIOSAFETY
--------------------------------------------------------

  CREATE TABLE "CVBIOSAFETY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
