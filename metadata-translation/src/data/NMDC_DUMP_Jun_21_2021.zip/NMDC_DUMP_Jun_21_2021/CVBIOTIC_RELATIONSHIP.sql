--------------------------------------------------------
--  DDL for Table CVBIOTIC_RELATIONSHIP
--------------------------------------------------------

  CREATE TABLE "CVBIOTIC_RELATIONSHIP" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
