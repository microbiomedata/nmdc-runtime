--------------------------------------------------------
--  DDL for Table CVBODY_PRODUCT
--------------------------------------------------------

  CREATE TABLE "CVBODY_PRODUCT" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER(*,0)
   )
