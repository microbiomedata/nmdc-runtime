--------------------------------------------------------
--  DDL for Table CVBODY_SUBSITE
--------------------------------------------------------

  CREATE TABLE "CVBODY_SUBSITE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(500), 
	"SEQUENCE" NUMBER(*,0)
   )
