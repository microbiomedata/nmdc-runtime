--------------------------------------------------------
--  DDL for Table CVCELL_SHAPE
--------------------------------------------------------

  CREATE TABLE "CVCELL_SHAPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" NUMBER(*,0)
   )
