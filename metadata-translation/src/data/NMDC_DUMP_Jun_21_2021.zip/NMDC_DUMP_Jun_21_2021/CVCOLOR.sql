--------------------------------------------------------
--  DDL for Table CVCOLOR
--------------------------------------------------------

  CREATE TABLE "CVCOLOR" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" NUMBER(*,0)
   )
