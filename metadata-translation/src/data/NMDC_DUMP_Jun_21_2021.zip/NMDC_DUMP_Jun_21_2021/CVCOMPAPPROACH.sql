--------------------------------------------------------
--  DDL for Table CVCOMPAPPROACH
--------------------------------------------------------

  CREATE TABLE "CVCOMPAPPROACH" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
