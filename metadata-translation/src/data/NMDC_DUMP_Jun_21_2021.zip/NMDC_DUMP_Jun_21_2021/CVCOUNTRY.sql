--------------------------------------------------------
--  DDL for Table CVCOUNTRY
--------------------------------------------------------

  CREATE TABLE "CVCOUNTRY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
