--------------------------------------------------------
--  DDL for Table CVCOVERAGESOFTWARE
--------------------------------------------------------

  CREATE TABLE "CVCOVERAGESOFTWARE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
