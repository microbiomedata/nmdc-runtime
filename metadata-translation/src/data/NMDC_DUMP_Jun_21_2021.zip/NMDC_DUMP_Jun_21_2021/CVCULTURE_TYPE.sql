--------------------------------------------------------
--  DDL for Table CVCULTURE_TYPE
--------------------------------------------------------

  CREATE TABLE "CVCULTURE_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
