--------------------------------------------------------
--  DDL for Table CVCURRENT_LAND_USE
--------------------------------------------------------

  CREATE TABLE "CVCURRENT_LAND_USE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
