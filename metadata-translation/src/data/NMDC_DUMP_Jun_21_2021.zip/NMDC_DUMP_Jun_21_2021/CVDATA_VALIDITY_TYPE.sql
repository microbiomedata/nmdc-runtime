--------------------------------------------------------
--  DDL for Table CVDATA_VALIDITY_TYPE
--------------------------------------------------------

  CREATE TABLE "CVDATA_VALIDITY_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
