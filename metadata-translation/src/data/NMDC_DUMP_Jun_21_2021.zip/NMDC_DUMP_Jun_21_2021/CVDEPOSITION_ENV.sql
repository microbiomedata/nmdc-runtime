--------------------------------------------------------
--  DDL for Table CVDEPOSITION_ENV
--------------------------------------------------------

  CREATE TABLE "CVDEPOSITION_ENV" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
