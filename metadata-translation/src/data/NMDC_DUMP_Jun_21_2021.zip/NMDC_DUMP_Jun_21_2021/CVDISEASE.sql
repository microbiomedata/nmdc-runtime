--------------------------------------------------------
--  DDL for Table CVDISEASE
--------------------------------------------------------

  CREATE TABLE "CVDISEASE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
