--------------------------------------------------------
--  DDL for Table CVDOMAIN
--------------------------------------------------------

  CREATE TABLE "CVDOMAIN" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
