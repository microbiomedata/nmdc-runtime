--------------------------------------------------------
--  DDL for Table CVFINISHING_GOAL
--------------------------------------------------------

  CREATE TABLE "CVFINISHING_GOAL" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
