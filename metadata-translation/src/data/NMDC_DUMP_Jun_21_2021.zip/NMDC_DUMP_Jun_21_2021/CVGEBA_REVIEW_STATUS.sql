--------------------------------------------------------
--  DDL for Table CVGEBA_REVIEW_STATUS
--------------------------------------------------------

  CREATE TABLE "CVGEBA_REVIEW_STATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
