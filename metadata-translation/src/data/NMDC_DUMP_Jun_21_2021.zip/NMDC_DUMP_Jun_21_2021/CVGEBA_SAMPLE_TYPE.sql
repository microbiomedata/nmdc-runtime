--------------------------------------------------------
--  DDL for Table CVGEBA_SAMPLE_TYPE
--------------------------------------------------------

  CREATE TABLE "CVGEBA_SAMPLE_TYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
