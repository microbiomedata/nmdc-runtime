--------------------------------------------------------
--  DDL for Table CVGEBA_TYPES
--------------------------------------------------------

  CREATE TABLE "CVGEBA_TYPES" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
