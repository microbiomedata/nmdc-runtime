--------------------------------------------------------
--  DDL for Table CVGRAM_STAIN
--------------------------------------------------------

  CREATE TABLE "CVGRAM_STAIN" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
