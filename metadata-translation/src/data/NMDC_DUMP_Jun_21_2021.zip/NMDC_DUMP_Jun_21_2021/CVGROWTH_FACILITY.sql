--------------------------------------------------------
--  DDL for Table CVGROWTH_FACILITY
--------------------------------------------------------

  CREATE TABLE "CVGROWTH_FACILITY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
