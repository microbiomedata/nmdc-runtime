--------------------------------------------------------
--  DDL for Table CVHEALTHDISEASESTATUS
--------------------------------------------------------

  CREATE TABLE "CVHEALTHDISEASESTATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
