--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_GEOLOGICALAGE
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_GEOLOGICALAGE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
