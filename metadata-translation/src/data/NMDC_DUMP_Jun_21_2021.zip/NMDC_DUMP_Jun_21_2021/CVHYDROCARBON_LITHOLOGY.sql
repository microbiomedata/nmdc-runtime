--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_LITHOLOGY
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_LITHOLOGY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
