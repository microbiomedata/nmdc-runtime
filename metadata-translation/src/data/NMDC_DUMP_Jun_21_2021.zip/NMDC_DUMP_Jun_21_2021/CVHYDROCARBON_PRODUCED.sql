--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_PRODUCED
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_PRODUCED" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
