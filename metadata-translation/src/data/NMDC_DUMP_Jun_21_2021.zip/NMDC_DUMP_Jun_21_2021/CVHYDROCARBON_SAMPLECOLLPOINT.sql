--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_SAMPLECOLLPOINT
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_SAMPLECOLLPOINT" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
