--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_SAMPLETYPE
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_SAMPLETYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
