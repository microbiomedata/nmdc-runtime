--------------------------------------------------------
--  DDL for Table CVIMGUSE
--------------------------------------------------------

  CREATE TABLE "CVIMGUSE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" NUMBER(*,0)
   )
