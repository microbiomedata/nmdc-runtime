--------------------------------------------------------
--  DDL for Table CVIRRADIANCE
--------------------------------------------------------

  CREATE TABLE "CVIRRADIANCE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
