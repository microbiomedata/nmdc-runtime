--------------------------------------------------------
--  DDL for Table CVLATLONG
--------------------------------------------------------

  CREATE TABLE "CVLATLONG" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
