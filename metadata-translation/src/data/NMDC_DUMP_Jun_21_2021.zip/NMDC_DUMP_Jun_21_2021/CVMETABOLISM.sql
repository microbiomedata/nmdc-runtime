--------------------------------------------------------
--  DDL for Table CVMETABOLISM
--------------------------------------------------------

  CREATE TABLE "CVMETABOLISM" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
