--------------------------------------------------------
--  DDL for Table CVMODEL
--------------------------------------------------------

  CREATE TABLE "CVMODEL" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
