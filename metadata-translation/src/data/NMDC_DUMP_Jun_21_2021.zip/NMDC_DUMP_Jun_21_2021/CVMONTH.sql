--------------------------------------------------------
--  DDL for Table CVMONTH
--------------------------------------------------------

  CREATE TABLE "CVMONTH" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" NUMBER
   )
