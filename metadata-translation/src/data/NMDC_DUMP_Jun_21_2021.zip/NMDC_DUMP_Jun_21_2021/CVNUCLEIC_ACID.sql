--------------------------------------------------------
--  DDL for Table CVNUCLEIC_ACID
--------------------------------------------------------

  CREATE TABLE "CVNUCLEIC_ACID" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER
   )
