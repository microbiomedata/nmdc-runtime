--------------------------------------------------------
--  DDL for Table CVORGANISM_TYPE
--------------------------------------------------------

  CREATE TABLE "CVORGANISM_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
