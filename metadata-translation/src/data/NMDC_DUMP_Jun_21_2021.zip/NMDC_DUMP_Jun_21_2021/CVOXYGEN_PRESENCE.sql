--------------------------------------------------------
--  DDL for Table CVOXYGEN_PRESENCE
--------------------------------------------------------

  CREATE TABLE "CVOXYGEN_PRESENCE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
