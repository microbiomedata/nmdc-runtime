--------------------------------------------------------
--  DDL for Table CVPACKAGES
--------------------------------------------------------

  CREATE TABLE "CVPACKAGES" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
