--------------------------------------------------------
--  DDL for Table CVPHENOTYPE
--------------------------------------------------------

  CREATE TABLE "CVPHENOTYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
