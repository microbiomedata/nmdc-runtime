--------------------------------------------------------
--  DDL for Table CVPHYLOGENY
--------------------------------------------------------

  CREATE TABLE "CVPHYLOGENY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
