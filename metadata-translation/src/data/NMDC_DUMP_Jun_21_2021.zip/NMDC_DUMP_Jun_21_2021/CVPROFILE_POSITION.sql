--------------------------------------------------------
--  DDL for Table CVPROFILE_POSITION
--------------------------------------------------------

  CREATE TABLE "CVPROFILE_POSITION" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
