--------------------------------------------------------
--  DDL for Table CVRELATION
--------------------------------------------------------

  CREATE TABLE "CVRELATION" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER
   )
