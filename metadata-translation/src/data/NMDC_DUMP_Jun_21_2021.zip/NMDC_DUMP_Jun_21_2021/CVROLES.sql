--------------------------------------------------------
--  DDL for Table CVROLES
--------------------------------------------------------

  CREATE TABLE "CVROLES" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
