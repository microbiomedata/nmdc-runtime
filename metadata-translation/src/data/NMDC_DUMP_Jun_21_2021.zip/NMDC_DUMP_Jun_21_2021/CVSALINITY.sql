--------------------------------------------------------
--  DDL for Table CVSALINITY
--------------------------------------------------------

  CREATE TABLE "CVSALINITY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
