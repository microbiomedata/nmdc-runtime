--------------------------------------------------------
--  DDL for Table CVSAMPLECAPTURE_STATUS
--------------------------------------------------------

  CREATE TABLE "CVSAMPLECAPTURE_STATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
