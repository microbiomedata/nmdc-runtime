--------------------------------------------------------
--  DDL for Table CVSEDIMENT_TYPE
--------------------------------------------------------

  CREATE TABLE "CVSEDIMENT_TYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
