--------------------------------------------------------
--  DDL for Table CVSOILFAOCLASS
--------------------------------------------------------

  CREATE TABLE "CVSOILFAOCLASS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
