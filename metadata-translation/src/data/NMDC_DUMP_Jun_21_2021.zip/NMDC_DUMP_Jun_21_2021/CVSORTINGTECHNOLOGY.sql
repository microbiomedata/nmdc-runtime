--------------------------------------------------------
--  DDL for Table CVSORTINGTECHNOLOGY
--------------------------------------------------------

  CREATE TABLE "CVSORTINGTECHNOLOGY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
