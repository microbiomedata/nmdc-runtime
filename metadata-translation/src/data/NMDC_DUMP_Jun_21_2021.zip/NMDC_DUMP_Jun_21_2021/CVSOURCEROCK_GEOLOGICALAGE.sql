--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_GEOLOGICALAGE
--------------------------------------------------------

  CREATE TABLE "CVSOURCEROCK_GEOLOGICALAGE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
