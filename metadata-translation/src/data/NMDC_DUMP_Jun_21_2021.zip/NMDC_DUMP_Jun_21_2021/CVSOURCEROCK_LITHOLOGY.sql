--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_LITHOLOGY
--------------------------------------------------------

  CREATE TABLE "CVSOURCEROCK_LITHOLOGY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
