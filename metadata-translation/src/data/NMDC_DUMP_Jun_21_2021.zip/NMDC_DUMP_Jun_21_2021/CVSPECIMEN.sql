--------------------------------------------------------
--  DDL for Table CVSPECIMEN
--------------------------------------------------------

  CREATE TABLE "CVSPECIMEN" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" VARCHAR2(20)
   )
