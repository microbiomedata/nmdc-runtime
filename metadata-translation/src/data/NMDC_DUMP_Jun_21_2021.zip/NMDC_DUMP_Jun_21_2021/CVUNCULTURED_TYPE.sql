--------------------------------------------------------
--  DDL for Table CVUNCULTURED_TYPE
--------------------------------------------------------

  CREATE TABLE "CVUNCULTURED_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
