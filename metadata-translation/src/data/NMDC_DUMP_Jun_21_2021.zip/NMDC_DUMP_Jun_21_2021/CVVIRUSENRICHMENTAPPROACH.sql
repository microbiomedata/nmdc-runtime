--------------------------------------------------------
--  DDL for Table CVVIRUSENRICHMENTAPPROACH
--------------------------------------------------------

  CREATE TABLE "CVVIRUSENRICHMENTAPPROACH" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
