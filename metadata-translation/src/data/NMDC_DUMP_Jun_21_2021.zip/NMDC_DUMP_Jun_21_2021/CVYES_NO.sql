--------------------------------------------------------
--  DDL for Table CVYES_NO
--------------------------------------------------------

  CREATE TABLE "CVYES_NO" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
