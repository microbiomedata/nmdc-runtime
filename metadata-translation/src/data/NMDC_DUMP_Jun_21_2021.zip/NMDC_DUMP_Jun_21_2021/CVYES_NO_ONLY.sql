--------------------------------------------------------
--  DDL for Table CVYES_NO_ONLY
--------------------------------------------------------

  CREATE TABLE "CVYES_NO_ONLY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
