--------------------------------------------------------
--  DDL for Table ENVO_TERMS_LABELS
--------------------------------------------------------

  CREATE TABLE "ENVO_TERMS_LABELS" 
   (	"ENVO_TERM_ID" VARCHAR2(100), 
	"ENVO_TERM_LABEL" VARCHAR2(1000)
   )
