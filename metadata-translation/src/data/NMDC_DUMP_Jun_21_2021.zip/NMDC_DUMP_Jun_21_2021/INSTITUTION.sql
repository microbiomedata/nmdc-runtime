--------------------------------------------------------
--  DDL for Table INSTITUTION
--------------------------------------------------------

  CREATE TABLE "INSTITUTION" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(512), 
	"URL" VARCHAR2(500), 
	"COUNTRY" VARCHAR2(100), 
	"ORGANIZATION" VARCHAR2(200), 
	"DEPARTMENT" VARCHAR2(200), 
	"LABORATORY" VARCHAR2(200), 
	"IS_CURATED" VARCHAR2(3) DEFAULT 'No'
   )
