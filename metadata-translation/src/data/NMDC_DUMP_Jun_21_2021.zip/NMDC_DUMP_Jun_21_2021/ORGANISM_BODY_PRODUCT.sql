--------------------------------------------------------
--  DDL for Table ORGANISM_BODY_PRODUCT
--------------------------------------------------------

  CREATE TABLE "ORGANISM_BODY_PRODUCT" 
   (	"ORGANISM_ID" NUMBER(*,0), 
	"BODY_PRODUCT_ID" NUMBER(*,0)
   )
