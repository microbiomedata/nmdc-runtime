--------------------------------------------------------
--  DDL for Table ORGANISM_ENERGY_SOURCE
--------------------------------------------------------

  CREATE TABLE "ORGANISM_ENERGY_SOURCE" 
   (	"ORGANISM_ID" NUMBER(*,0), 
	"ENERGY_SOURCE_ID" NUMBER(*,0)
   )
