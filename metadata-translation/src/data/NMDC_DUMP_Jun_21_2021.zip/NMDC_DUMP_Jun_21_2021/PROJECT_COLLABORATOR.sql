--------------------------------------------------------
--  DDL for Table PROJECT_COLLABORATOR
--------------------------------------------------------

  CREATE TABLE "PROJECT_COLLABORATOR" 
   (	"PROJECT_ID" NUMBER, 
	"INSTITUTION_ID" NUMBER
   )
