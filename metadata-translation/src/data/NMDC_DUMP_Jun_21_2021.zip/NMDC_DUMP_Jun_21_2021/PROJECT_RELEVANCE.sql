--------------------------------------------------------
--  DDL for Table PROJECT_RELEVANCE
--------------------------------------------------------

  CREATE TABLE "PROJECT_RELEVANCE" 
   (	"PROJECT_ID" NUMBER, 
	"RELEVANCE_ID" NUMBER
   )
