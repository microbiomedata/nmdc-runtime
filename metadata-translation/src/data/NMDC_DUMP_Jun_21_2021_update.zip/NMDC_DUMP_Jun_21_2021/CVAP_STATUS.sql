--------------------------------------------------------
--  DDL for Table CVAP_STATUS
--------------------------------------------------------

  CREATE TABLE "CVAP_STATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER
   )
