--------------------------------------------------------
--  DDL for Table CVAVAILABILITY
--------------------------------------------------------

  CREATE TABLE "CVAVAILABILITY" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" NUMBER(*,0)
   )
