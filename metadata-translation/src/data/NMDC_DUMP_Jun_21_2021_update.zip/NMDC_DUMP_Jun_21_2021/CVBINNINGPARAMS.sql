--------------------------------------------------------
--  DDL for Table CVBINNINGPARAMS
--------------------------------------------------------

  CREATE TABLE "CVBINNINGPARAMS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
