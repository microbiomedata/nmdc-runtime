--------------------------------------------------------
--  DDL for Table CVBIOLOGICAL_STATUS
--------------------------------------------------------

  CREATE TABLE "CVBIOLOGICAL_STATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
