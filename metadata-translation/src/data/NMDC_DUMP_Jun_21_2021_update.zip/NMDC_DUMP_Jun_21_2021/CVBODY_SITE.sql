--------------------------------------------------------
--  DDL for Table CVBODY_SITE
--------------------------------------------------------

  CREATE TABLE "CVBODY_SITE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(500), 
	"SEQUENCE" NUMBER(*,0)
   )
