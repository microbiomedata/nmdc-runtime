--------------------------------------------------------
--  DDL for Table CVCELLLYSISAPPROACH
--------------------------------------------------------

  CREATE TABLE "CVCELLLYSISAPPROACH" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
