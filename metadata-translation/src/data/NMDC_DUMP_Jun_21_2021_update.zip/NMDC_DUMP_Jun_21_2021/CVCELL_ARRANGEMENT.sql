--------------------------------------------------------
--  DDL for Table CVCELL_ARRANGEMENT
--------------------------------------------------------

  CREATE TABLE "CVCELL_ARRANGEMENT" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(20), 
	"SEQUENCE" NUMBER(*,0)
   )
