--------------------------------------------------------
--  DDL for Table CVCONTAMINATIONSCREENING
--------------------------------------------------------

  CREATE TABLE "CVCONTAMINATIONSCREENING" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
