--------------------------------------------------------
--  DDL for Table CVDRAINAGE_CLASS
--------------------------------------------------------

  CREATE TABLE "CVDRAINAGE_CLASS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
