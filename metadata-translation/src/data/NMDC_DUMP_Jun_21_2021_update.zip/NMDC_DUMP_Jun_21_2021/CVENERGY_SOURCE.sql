--------------------------------------------------------
--  DDL for Table CVENERGY_SOURCE
--------------------------------------------------------

  CREATE TABLE "CVENERGY_SOURCE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
