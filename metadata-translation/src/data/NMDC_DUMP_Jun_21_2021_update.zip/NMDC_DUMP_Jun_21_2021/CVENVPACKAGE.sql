--------------------------------------------------------
--  DDL for Table CVENVPACKAGE
--------------------------------------------------------

  CREATE TABLE "CVENVPACKAGE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
