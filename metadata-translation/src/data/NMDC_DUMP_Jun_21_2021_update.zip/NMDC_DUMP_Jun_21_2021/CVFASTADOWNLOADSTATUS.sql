--------------------------------------------------------
--  DDL for Table CVFASTADOWNLOADSTATUS
--------------------------------------------------------

  CREATE TABLE "CVFASTADOWNLOADSTATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
