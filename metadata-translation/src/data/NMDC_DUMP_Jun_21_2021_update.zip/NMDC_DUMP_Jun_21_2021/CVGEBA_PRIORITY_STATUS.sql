--------------------------------------------------------
--  DDL for Table CVGEBA_PRIORITY_STATUS
--------------------------------------------------------

  CREATE TABLE "CVGEBA_PRIORITY_STATUS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
