--------------------------------------------------------
--  DDL for Table CVGROWTH_HABIT
--------------------------------------------------------

  CREATE TABLE "CVGROWTH_HABIT" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
