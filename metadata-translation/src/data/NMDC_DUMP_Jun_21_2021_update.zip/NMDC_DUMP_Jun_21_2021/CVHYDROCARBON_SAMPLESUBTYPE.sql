--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_SAMPLESUBTYPE
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_SAMPLESUBTYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
