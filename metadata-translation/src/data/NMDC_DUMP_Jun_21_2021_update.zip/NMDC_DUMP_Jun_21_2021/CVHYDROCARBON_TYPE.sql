--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_TYPE
--------------------------------------------------------

  CREATE TABLE "CVHYDROCARBON_TYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
