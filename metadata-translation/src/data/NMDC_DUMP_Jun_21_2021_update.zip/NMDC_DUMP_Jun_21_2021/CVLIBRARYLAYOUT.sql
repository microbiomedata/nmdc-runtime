--------------------------------------------------------
--  DDL for Table CVLIBRARYLAYOUT
--------------------------------------------------------

  CREATE TABLE "CVLIBRARYLAYOUT" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
