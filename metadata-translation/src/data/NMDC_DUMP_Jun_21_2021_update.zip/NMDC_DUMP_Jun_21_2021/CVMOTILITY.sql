--------------------------------------------------------
--  DDL for Table CVMOTILITY
--------------------------------------------------------

  CREATE TABLE "CVMOTILITY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
