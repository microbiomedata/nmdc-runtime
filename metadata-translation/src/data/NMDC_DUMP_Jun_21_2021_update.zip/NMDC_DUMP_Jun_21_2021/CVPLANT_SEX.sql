--------------------------------------------------------
--  DDL for Table CVPLANT_SEX
--------------------------------------------------------

  CREATE TABLE "CVPLANT_SEX" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
