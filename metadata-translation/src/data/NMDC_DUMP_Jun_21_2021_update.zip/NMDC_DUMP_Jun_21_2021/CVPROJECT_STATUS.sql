--------------------------------------------------------
--  DDL for Table CVPROJECT_STATUS
--------------------------------------------------------

  CREATE TABLE "CVPROJECT_STATUS" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
