--------------------------------------------------------
--  DDL for Table CVPROJECT_SUBTYPE
--------------------------------------------------------

  CREATE TABLE "CVPROJECT_SUBTYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
