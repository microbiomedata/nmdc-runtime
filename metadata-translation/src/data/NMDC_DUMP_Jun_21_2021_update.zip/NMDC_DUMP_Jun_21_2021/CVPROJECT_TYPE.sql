--------------------------------------------------------
--  DDL for Table CVPROJECT_TYPE
--------------------------------------------------------

  CREATE TABLE "CVPROJECT_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
