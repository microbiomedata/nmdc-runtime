--------------------------------------------------------
--  DDL for Table CVRELEVANCE
--------------------------------------------------------

  CREATE TABLE "CVRELEVANCE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
