--------------------------------------------------------
--  DDL for Table CVSEQ_QUALITY
--------------------------------------------------------

  CREATE TABLE "CVSEQ_QUALITY" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
