--------------------------------------------------------
--  DDL for Table CVSEQ_STATUS
--------------------------------------------------------

  CREATE TABLE "CVSEQ_STATUS" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
