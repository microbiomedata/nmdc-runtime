--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_DEPOSITION
--------------------------------------------------------

  CREATE TABLE "CVSOURCEROCK_DEPOSITION" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
