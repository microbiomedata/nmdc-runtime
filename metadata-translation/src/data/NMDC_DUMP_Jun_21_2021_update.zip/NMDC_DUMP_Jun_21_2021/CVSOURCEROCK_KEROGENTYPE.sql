--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_KEROGENTYPE
--------------------------------------------------------

  CREATE TABLE "CVSOURCEROCK_KEROGENTYPE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
