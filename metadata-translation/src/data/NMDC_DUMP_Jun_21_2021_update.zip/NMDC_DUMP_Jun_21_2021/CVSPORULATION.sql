--------------------------------------------------------
--  DDL for Table CVSPORULATION
--------------------------------------------------------

  CREATE TABLE "CVSPORULATION" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
