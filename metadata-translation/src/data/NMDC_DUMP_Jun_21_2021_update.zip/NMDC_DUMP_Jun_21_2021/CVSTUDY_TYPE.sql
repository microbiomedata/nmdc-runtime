--------------------------------------------------------
--  DDL for Table CVSTUDY_TYPE
--------------------------------------------------------

  CREATE TABLE "CVSTUDY_TYPE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(30), 
	"SEQUENCE" VARCHAR2(20)
   )
