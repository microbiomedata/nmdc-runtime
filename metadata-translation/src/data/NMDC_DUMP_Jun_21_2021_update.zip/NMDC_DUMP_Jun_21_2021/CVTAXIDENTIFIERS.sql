--------------------------------------------------------
--  DDL for Table CVTAXIDENTIFIERS
--------------------------------------------------------

  CREATE TABLE "CVTAXIDENTIFIERS" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(200), 
	"SEQUENCE" NUMBER
   )
