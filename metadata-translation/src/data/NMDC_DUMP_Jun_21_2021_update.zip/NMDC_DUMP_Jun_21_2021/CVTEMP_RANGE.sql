--------------------------------------------------------
--  DDL for Table CVTEMP_RANGE
--------------------------------------------------------

  CREATE TABLE "CVTEMP_RANGE" 
   (	"ID" NUMBER(*,0), 
	"TERM" VARCHAR2(100), 
	"SEQUENCE" NUMBER(*,0)
   )
