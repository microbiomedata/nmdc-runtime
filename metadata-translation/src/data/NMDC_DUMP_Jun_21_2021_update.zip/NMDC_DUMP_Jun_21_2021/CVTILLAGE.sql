--------------------------------------------------------
--  DDL for Table CVTILLAGE
--------------------------------------------------------

  CREATE TABLE "CVTILLAGE" 
   (	"ID" NUMBER, 
	"TERM" VARCHAR2(50), 
	"SEQUENCE" NUMBER
   )
