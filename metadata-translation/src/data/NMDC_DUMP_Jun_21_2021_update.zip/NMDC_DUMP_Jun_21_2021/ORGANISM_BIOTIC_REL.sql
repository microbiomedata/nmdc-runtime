--------------------------------------------------------
--  DDL for Table ORGANISM_BIOTIC_REL
--------------------------------------------------------

  CREATE TABLE "ORGANISM_BIOTIC_REL" 
   (	"ORGANISM_ID" NUMBER(*,0), 
	"BIOTIC_RELATIONSHIP_ID" NUMBER(*,0)
   )
