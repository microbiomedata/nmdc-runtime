--------------------------------------------------------
--  DDL for Table ORGANISM_DISEASE
--------------------------------------------------------

  CREATE TABLE "ORGANISM_DISEASE" 
   (	"ORGANISM_ID" NUMBER(*,0), 
	"DISEASE_ID" NUMBER(*,0)
   )
