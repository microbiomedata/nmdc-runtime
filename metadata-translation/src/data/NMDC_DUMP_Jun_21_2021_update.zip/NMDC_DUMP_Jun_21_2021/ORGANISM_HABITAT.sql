--------------------------------------------------------
--  DDL for Table ORGANISM_HABITAT
--------------------------------------------------------

  CREATE TABLE "ORGANISM_HABITAT" 
   (	"ORGANISM_ID" NUMBER(*,0), 
	"HABITAT_ID" NUMBER(*,0)
   )
