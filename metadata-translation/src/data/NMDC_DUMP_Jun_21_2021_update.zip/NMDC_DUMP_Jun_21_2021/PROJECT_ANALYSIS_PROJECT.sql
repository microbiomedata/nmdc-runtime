--------------------------------------------------------
--  DDL for Table PROJECT_ANALYSIS_PROJECT
--------------------------------------------------------

  CREATE TABLE "PROJECT_ANALYSIS_PROJECT" 
   (	"PROJECT_ID" NUMBER, 
	"ANALYSIS_PROJECT_ID" NUMBER
   )
