--------------------------------------------------------
--  DDL for Table PROJECT_SEQUENCING_METHOD
--------------------------------------------------------

  CREATE TABLE "PROJECT_SEQUENCING_METHOD" 
   (	"PROJECT_ID" NUMBER, 
	"SEQUENCING_METHOD_ID" NUMBER
   )
