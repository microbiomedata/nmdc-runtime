--------------------------------------------------------
--  DDL for Table PUBLICATION
--------------------------------------------------------

  CREATE TABLE "PUBLICATION" 
   (	"PUBLICATION_ID" NUMBER(*,0), 
	"DOI" VARCHAR2(128), 
	"PUBMED_ID" NUMBER(*,0), 
	"JOURNAL_ID" NUMBER(*,0), 
	"PUBMODEL" VARCHAR2(128), 
	"VOLUME" VARCHAR2(128), 
	"ISSUE" VARCHAR2(128), 
	"PAGE" VARCHAR2(128), 
	"PUBLICATION_DATE" DATE, 
	"ABSTRACT" VARCHAR2(4000), 
	"AFFILIATION" VARCHAR2(4000), 
	"TITLE" VARCHAR2(1000), 
	"LAST_AUTHOR_ID" NUMBER(*,0), 
	"FIRST_AUTHOR_ID" NUMBER(*,0)
   )
