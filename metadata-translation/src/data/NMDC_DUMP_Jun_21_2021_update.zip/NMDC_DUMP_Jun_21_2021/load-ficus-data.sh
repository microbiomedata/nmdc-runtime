#!/bin/bash
for filename in *.dsv; do
    table=$(basename $filename _DATA_TABLE.dsv)
    #echo "file: $filename table $table"
    echo "importing $filename into $table"
    sqlite3 ficus_publicdb.db -cmd ".mode tabs" ".import $filename $table"
done
